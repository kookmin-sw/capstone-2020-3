"""
Debug variable used throughout the entire module.
Turns on debugging information.
"""

debug = False
